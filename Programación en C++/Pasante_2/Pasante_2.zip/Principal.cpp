#include "Pasante.hpp"
#include <conio.h>

int main(){
    Pasante Flip;
    Flip=Leer_Datos();
    Flip.Imprimir_Datos_Pasante();
    getch();
    return 1;
    }
