#include <conio.h>
#include <PlanV.hpp>

int main(){
     planV x;
     x.ImprimirDatos();
     getch();
     return 0;
    }
