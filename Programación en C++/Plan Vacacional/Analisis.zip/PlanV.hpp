#include <iostream>
#include <string.h>
using namespace std;
class planV : public Boleto, public Hotel{
      char Descripcion[80];
      public:
             planV();
             planV(int f , float , char *, char *, char *,int , float , char *, char *, char *, char *);
             void ImprimirDatos();
      };

planV::planV(){}
planV::planV(int f ,float i ,char fol[], char co[], char ci[],int h ,int d , float p , char th[],char Desc[]){
              strcpy(Descripcion,Desc);             
             }
             
void planV::ImprimirDatos(){
     cout << endl;
     cout << "----------Plan Vacacional--------";
     cout << "Descripcion del plan VACACIONAL"<<endl;
     cout << Descripcion;
     }

planV leeDatos(){
      char CO[15], CD[15], Fol[15], Descrip[80], TipoHabitacion[10];
      float precio, importes;
      int dura, numeroh, fe;
      cout << "Ciudad Origen: ";
      gets(CO);
      fflush(stdin);
      cout << "Ciudad Destino: ";
      gets(CD);
      fflush(stdin);
      cout << "Precio del Boleto de Viaje: ";
      cin >> precio;
      cout << "Boleto numero: ";
      gets(Fol);
      fflush(stdin);
      cout << "Tipo de Habitacion: ";
      gets(TipoHabitacion);
      fflush(stdin);
      cout << "Duracion de la estancia en el Hotel: ";
      cin >> dura;
      if(TipoHabitacion== "S")
        importes=1200 * dura;
      else
        importes=2000 * dura;
      cout << "Fecha de ingreso al Hotel (ddmmyyyy): ";
      cin >> fe;
      cout << "Numero de habitacion: ";
      cin >> numeroh;
      cout << "Descripcion del plan vacacional";
      gets(Descrip);
      fflush(stdin);
      planV Paquete(fe ,importes,Fol, CO, CD,numeroh ,dura , precio , TipoHabitacion, Descrip);
      return Paquete;
}
