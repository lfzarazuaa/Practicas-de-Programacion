#include<iostream>
#include<string.h>

using namespace std;

class Hotel{
      protected:
      int habitacion;
      int duracion;
      float precio;
      char tipoh[10]
      public:
             Hotel();
             Hotel(int,int,float,char*);
             void imprimir();
      };
      
Hotel::Hotel
Hotel::Hotel(int h ,int d , float p , char th[]){
                       habitacion = h;
                       duracion =d;
                       precio =p;
                       strcpy(tipoh,th);
                       }

void Hotel::iprimir(){
     cout<<".........................Hotel Emperador ....................."<<endl;
     cout<<"habitacion"<<habitacion<<endl;
     cout<<".............estancia"<<duracion<<endl;
     cout<<"....tipo de habitacion........................"<<tipoh<<endl;
     cout<<".........costo de estancia....................."<<precio<<endl;
     cout<<"......................... ....................."<<endl;
}
