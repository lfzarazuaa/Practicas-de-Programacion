

import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author SDK
 */
public class Window extends JFrame{
    JPanel Origen;
    JPanel Destino;
    ImageIcon Imagen;
    BufferedImage ImagenOrigen;
    FlowLayout Distribucion;
    JLabel Car;
    Window() throws IOException
    {
        Origen=new JPanel();
        Destino=new JPanel();
        Imagen=new ImageIcon();
        Distribucion=new FlowLayout();
        ImagenOrigen=ImageIO.read(this.getClass().getResource("R8.png"));
        Imagen.setImage(ImagenOrigen);
        Car=new JLabel(Imagen);
        
    }
    
    void Init()
    {
        Origen.add(Car);
        setLayout(Distribucion);
        add(Origen);
        add(Destino);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(640,480);
        setVisible(true);
        
        
    }
    
    
}
